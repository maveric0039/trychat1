import { useState } from "react";
import "./index.css";

export default function RelationshipChat() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Hi there. What's on your mind today?" },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages([...messages, { sender: "user", text: input }]);
    setInput("");

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          text: "Thanks for sharing. I'm here to listen and help however I can.",
        },
      ]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-xl shadow-xl bg-white rounded-xl p-6 space-y-4">
        <h1 className="text-xl font-semibold text-center">
          Let's Talk – Relationship Support Chat
        </h1>
        <div className="h-80 overflow-y-auto space-y-2 bg-gray-100 p-3 rounded border">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`p-2 rounded max-w-[80%] ${
                msg.sender === "user"
                  ? "bg-blue-100 self-end ml-auto text-right"
                  : "bg-gray-200 self-start mr-auto text-left"
              }`}
            >
              {msg.text}
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            className="flex-1 border rounded p-2"
            placeholder="Type your message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded"
            onClick={handleSend}
          >
            Send
          </button>
        </div>
        <p className="text-xs text-gray-500 text-center">
          Your identity remains completely anonymous.
        </p>
      </div>
    </div>
  );
}
